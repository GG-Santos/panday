# Dependency Update Workflow

Use `uv` for all commands. See [uv-commands.md](uv-commands.md) for command reference.

## Version Checking and Updates

### Check Outdated Packages

```bash
cd "$WORKTREE_PATH/<directory>"
uv pip list --outdated
```

> **Prerequisite:** `uv sync` must have run first (SKILL.md step 4) so the environment is populated and `uv pip list --outdated` can compare installed vs. PyPI versions.

> **Note:** `uv pip list --outdated` compares installed versions to PyPI latest and does not account for version range constraints in `pyproject.toml`. A package may appear outdated but be unupgradable given its constraints — the update step handles this.

For specific packages, check available versions:
```bash
uv index versions <package>
```

### Apply Version Filters

Compare each outdated package's current and latest versions to determine its update type, then include only packages matching the Q2a version scope:

- **"Patch only"**: Include packages where only the patch version differs (major and minor are the same).
- **"Patch + Minor" (default)**: Include packages where the patch or minor version differs (major is the same).
- **"Patch + Minor + Major"**: Include all updates regardless of which version component changed.

**Skip x.y.0 releases (Q3):** This option is only presented when Q2a was "Patch + Minor" or "Patch + Minor + Major" (i.e. when minor updates are in scope). If the user selected "Yes, skip x.y.0", exclude any package whose latest version has patch=0 **and minor>0** (e.g. `2.1.0`) — wait for `x.y.1+`. Do **not** apply this filter to `x.0.0` major releases (e.g. `3.0.0`).

  Implementation check:
  ```python
  # latest_version is a tuple (major, minor, patch)
  should_skip = (
      skip_x_y_0_selected
      and latest_version[2] == 0   # patch is 0
      and latest_version[1] > 0    # minor > 0 (not a major release)
  )
  ```

**Non-semver versions:** Some packages use CalVer (`2024.1.0`), pre-releases (`3.0a1`), or post-releases (`1.0.post1`). Version tuple comparisons won't work reliably for these. If a package's current or latest version can't be parsed as `(major, minor, patch)` integers, skip the version-scope filter and include it if `uv pip list --outdated` reports it as outdated — let uv resolve whether an upgrade is possible.

### Determine Strategy

Always update packages **sequentially within a directory** — parallel updates cause `uv.lock` contention.

Parallelize **across directories** only: if multiple directories have outdated packages, process them in parallel using separate Task subagents (general-purpose), running in background. Collect results from all agents before generating the final report.

### Update Packages

Update both pyproject.toml and the lockfile. First, check the project's existing version specifier style in `pyproject.toml`:

- **Exact pins** (`==1.2.3`): Use `uv add <pkg>==<latest_version>`
- **Range constraints** (`>=1.2,<2.0` or `~=1.2`): Edit `pyproject.toml` using file editing tools to update the range bounds, then run `uv lock --upgrade-package <pkg>` and `uv sync`
- **Unpinned** (`requests` with no specifier): Use `uv add <pkg>` (no version) to pull latest and let uv resolve

```bash
cd "$WORKTREE_PATH/<directory>"

# Check latest version
uv index versions <package>

# For exact-pinned projects:
uv add <package>==<latest_version>

# For range-constrained projects:
# Edit pyproject.toml manually, then:
uv lock --upgrade-package <package>
uv sync

# For dev dependencies — check pyproject.toml to pick the right flag:
#   [project.optional-dependencies] → uv add --optional dev <pkg>==<version>
#   [dependency-groups] (PEP 735)   → uv add --group dev <pkg>==<version>

# Sync environment (match the pattern above):
#   [project.optional-dependencies] → uv sync --extra dev
#   [dependency-groups] (PEP 735)   → uv sync --group dev
```

If `uv add <pkg>==<latest_version>` fails due to version constraints, try letting uv resolve the best compatible version:
```bash
uv add <package>  # no version pin — uv picks latest compatible with existing constraints
```
If that also fails, document the constraint conflict in the PR description and skip this package.

Validate after each update per SKILL.md step 6. If validation fails, revert (see SKILL.md step 6) before continuing.

### Update Documentation for Major Version Changes

For major version upgrades, search markdown files (`CLAUDE.md`, `README.md`, `docs/*.md`) for version references and update them. Include changes in the PR description.

### Workspace Projects

For uv workspaces (`[tool.uv.workspace]` in root `pyproject.toml`), run all `uv add`, `uv lock`, and `uv sync` commands from the workspace root. Member `pyproject.toml` files may still need direct edits for range constraints.

### Run Security Audit

After updating, check for new vulnerabilities (see [uv-commands.md](uv-commands.md) for details on this pattern):
```bash
cd "$WORKTREE_PATH/<directory>"
AUDIT_JSON=$(uv export --frozen --no-emit-project | uvx pip-audit --strict --format json --desc -r /dev/stdin --disable-pip --no-deps 2>/dev/null)
AUDIT_EXIT=$?

# Retry without --strict only when strict run found no real vulns
# (distinguishes database-coverage warning from actual vulnerabilities)
if [ "$AUDIT_EXIT" -ne 0 ]; then
  STRICT_VULN_COUNT=$(echo "$AUDIT_JSON" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(sum(len(d['vulns']) for d in data['dependencies']))
except Exception:
    print(-1)
" 2>/dev/null)
  if [ "$STRICT_VULN_COUNT" = "0" ] || [ "$STRICT_VULN_COUNT" = "-1" ]; then
    AUDIT_JSON=$(uv export --frozen --no-emit-project | uvx pip-audit --format json --desc -r /dev/stdin --disable-pip --no-deps 2>/dev/null)
    AUDIT_EXIT=0
  fi
fi

VULN_COUNT=$(echo "$AUDIT_JSON" | python3 -c "import json,sys; data=json.load(sys.stdin); print(sum(len(d['vulns']) for d in data['dependencies']))" 2>/dev/null || echo "unknown")
```

Report a clean/vulnerable summary (e.g. "0 vulnerabilities" or "2 vulnerabilities found") — do not print raw JSON.

## Handle Results

### On Success

1. Set `COMMIT_MSG="chore: update Python dependencies"` and commit per SKILL.md step 7
2. Push branch to remote:
   ```bash
   git push -u origin "$BRANCH_NAME"
   ```
3. Check for existing dependency update PRs on this branch:
   ```bash
   gh pr list --head "$BRANCH_NAME" --state open
   ```
   If an open PR exists for this branch, update it with `gh pr edit` instead of creating a new one.
4. Create PR using gh CLI. Write the PR body to a temp file first (subshell heredocs `$(cat <<'EOF'...)` fail in sandbox):
   ```bash
   BODY_FILE=$(mktemp "${TMPDIR:-/private/tmp}/uv-deps-update-body-XXXXXX")
   cat > "$BODY_FILE" << 'PREOF'
   ## Summary
   - Updated packages: [list with old → new versions]
   - Breaking changes fixed: [list code modifications if any]

   ## Validation Results
   | Check | Status |
   |-------|--------|
   | Type Check (mypy) | pass/fail |
   | Lint (ruff) | pass/fail |
   | Tests (pytest) | pass/fail |
   | Security Audit (pip-audit) | clean/X vulnerabilities |

   ## Files Changed
   - [list modified pyproject.toml and uv.lock files]

   Generated with [Claude Code](https://claude.com/claude-code)
   PREOF
   gh pr create --title "chore: update Python dependencies" --body-file "$BODY_FILE"
   rm -f "$BODY_FILE"
   ```
5. Return the PR URL to the user

### On Failure

- Categorize errors (type check/lint/test/audit)
- Provide specific remediation steps
- If partially successful (some packages updated successfully): push the branch and create PR with failing checks noted in the PR description
- If nothing was successfully updated: offer options (isolate problem, revert specific updates, or abandon) rather than creating an empty PR
